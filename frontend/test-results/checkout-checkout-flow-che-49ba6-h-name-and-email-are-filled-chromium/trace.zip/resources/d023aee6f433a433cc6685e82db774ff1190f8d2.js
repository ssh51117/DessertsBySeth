(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_d87e0ddc._.js",
  "static/chunks/27ca6_next_dist_compiled_react-dom_c8a7b363._.js",
  "static/chunks/27ca6_next_dist_compiled_react-server-dom-turbopack_b1e0e7d6._.js",
  "static/chunks/27ca6_next_dist_compiled_next-devtools_index_6fa2e595.js",
  "static/chunks/27ca6_next_dist_compiled_126bb8eb._.js",
  "static/chunks/27ca6_next_dist_client_791945ab._.js",
  "static/chunks/27ca6_next_dist_6707c8cc._.js",
  "static/chunks/69652_@swc_helpers_cjs_679851cc._.js"
],
    source: "entry"
});
