(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__ed7cfe1f._.css",
  "static/chunks/27ca6_next_dist_f37cfeb0._.js",
  "static/chunks/src_components_CartProvider_tsx_b19eb7e5._.js"
],
    source: "dynamic"
});
